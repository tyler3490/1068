package tuj66923;
/*Tyler Hyde
 * 23 September 2019
 * Assignment 4. A Game
 * 
 * This program will play a game of Havasta with the user.
 * They will be shown the rules of the game and be prompted to select whether they 
 * 	want to play. 
 * Next the user will be asked to enter a move and it will then be compared with a 
 * 	randomly generated move from the computer.
 * The program will keep running as long as the user says they want to continue playing
 * 	but as soon as they do not the program will print out the total number of games 
 * 	played and how many have been won by the computer and the user. 
 * 
 */
import java.util.*;
public class Game {
	// This is an array of move choices used by the program.
	public static final String[] CHOICES = {"A", "S", "T", "G"};
	
	public static void main(String args[]) {
		Scanner in = new Scanner(System.in);
		
		//Initialize the counters to keep track of games played
		int gamesPlayed = 0;
		int playerWins = 0;
		int cpuWins = 0;
		
		//Print out the rules
		System.out.println("To pass the time during long voyages, Viking sailors would play the two-player game of Havsta.\n"
				+ "The rules are similar to rock, paper, sicissors but your choices are Applaro, Svartr�, Tunholmen, and Godafton.\n"
				+ "Applaro beats Svartr� and Tunholmen\n"
				+ "Svartr� beats Tunholmen\n"
				+ "Tunholmen beats Godafton\n"
				+ "Godafton beats Applaro and Svartr�\n"
				+ "To keep things simple from here on out we will just say A, S, T, or G.\n"
				+ "You will be playing against the computer and in the event of a tie the computer wins."
				+ "\n");
		
		while(true) {
			//Ask user if they want to play
			System.out.println("Would you like to play a round? Enter Y for yes or N for no.");
			String userChoice = in.next();
			
			// If user chooses to play, call the logic function and pass it the userChoice and cpuChoice functions as arguments, it will jump into the corresponding
			// 	functions and return both a user and computer choice.
			// These choices will then be passed to the logic function which will return either 0 or 1 indicating whether or not the user won (1 for a win, 0 for a loss).
			// The function will then go into the corresponding if statement and increment the counters accordingly. 
			if(userChoice.toUpperCase().equals("Y")){	
				int win = logic(userChoice(), cpuChoice());
				if(win == 1) {
					playerWins++;
					gamesPlayed++;
				}
				else {
					cpuWins++;
					gamesPlayed++;
				}
			}

			//If they choose to quit the game print out the number of times they played, the number of times the computer won, and the number of times the user won 
			else if(userChoice.toUpperCase().equals("N")) {
				System.out.printf("Total number of games played: " + gamesPlayed + "\n"
						+ "Number of player wins: " + playerWins + "\n"
						+ "Number of computer wins: " + cpuWins + "\n");
				break;
			}
			
			//If the user enters anything other than what is asked of them prompt them for a valid input
			else {
				System.out.println("Please enter a valid choice: either Y or N.");
			}		
		}
	}
	
	public static String userChoice() {
		/* This function will prompt the user to enter one of four possible moves and 
		 * 	return their choice as a String.
		 */
		
		while (true) {
			System.out.println("Choose your move. Enter A, S, T, G.");
			Scanner in = new Scanner(System.in);
			String userChoice = in.next();
			if(userChoice.toUpperCase().equals("A")) {
				return CHOICES[0];
			}
			else if(userChoice.toUpperCase().equals("S")) {
				return CHOICES[1];
			}
			else if(userChoice.toUpperCase().equals("T")) {
				return CHOICES[2];
			}
			else if(userChoice.toUpperCase().equals("G")) {
				return CHOICES[3];
			}
			
			// If the user enters an invalid input prompt them for a valid input
			else {
				System.out.println("Please enter valid input (A, S, T, or G).");
			}			
		}
	}

	public static String cpuChoice() {
		/* This function uses Java's built in random class to generate a number 
		 * 	between 0 and 3. This number corresponds to an index value of the array
		 * 	"CHOICE" that will determine the move of the computer.
		 */
		
		Random rand = new Random();
		int n = rand.nextInt(4);
		return CHOICES[n];		
	}

	public static int logic(String userChoice, String cpuChoice) {
		/*
		 * This function contains the logic to choose who won the game and uses  
		 * 	a switch statement based on what the users choice was. The function accepts
		 * 	2 parameters of String type, userChoice and cpuChoice.
		 * 
		 * Each choice the user has is a different case, contained within each case
		 * 	is the criteria for a user win.
		 * 
		 * The variable "win" is what the function returns, it is initialized to 0 and
		 * 	will only be set to 1 in the case of a user win. 
		 * 
		 * No matter if the user wins or loses this function will print out a statement
		 * 	saying what the outcome of the game was and tell the user what they
		 *  chose and what the computer chose. 
		 */
		int win = 0;
		switch(userChoice) {
			case "A":
				if (cpuChoice.equals("S") || cpuChoice.equals("T")){
					System.out.println("You won!, you chose A and the computer chose " + cpuChoice + ".");
					win = 1;
					break;
				}
				else {
					System.out.println("You lost, you chose A and the computer chose " + cpuChoice + ".");
					break;
					
				}
			case "S":
				if (cpuChoice.equals("T")){
					System.out.println("You won!, you chose S and the computer chose " + cpuChoice + ".");
					win = 1;
					break;
				}
				else {
					System.out.println("You lost, you chose S and the computer chose " + cpuChoice + ".");
					break;
				}
			case "T":
				if (cpuChoice.equals("G")){
					System.out.println("You won!, you chose T and the computer chose " + cpuChoice + ".");
					win = 1;
					break;
				}
				else {
					System.out.println("You lost, you chose T and the computer chose " + cpuChoice + ".");
					break;
				}
			case "G":
				if (cpuChoice.equals("A") || cpuChoice.equals("S")){
					System.out.println("You won!, you chose G and the computer chose " + cpuChoice + ".");
					win = 1;
					break;
				}
				else {
					System.out.println("You lost, you chose G and the computer chose " + cpuChoice + ".");
					break;
				}	
		}
		return win;
	}
}
