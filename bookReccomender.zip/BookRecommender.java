package tuj66923;

/*Tyler Hyde 
 *22 October 2019
 *
 * This program recommends a book to the user that they have not read.
 * First it asks the user to look at a list of books and rate each one on a scale of 1 to 5
 * 	then the program will take the ratings of 30 other people who also rated the book and compute a similarity score for each 
 * 	one depending on how similar their ratings are to the user.
 * The program will then average the scores of each book using the similarity scores as a weight, the more similar 
 * 	one person is to the user the more weight their ratings will carry. 
 * Using these weighted averages the program will tell the user what book they might like. 
 */

import java.util.*;
import java.io.*;

public class BookRecommender {
//	below are the 5 arrays required for the program
	public static final String bookNames[]  = new String[20];
	public static final int ratings[][]  = new int[30][20];
	public static final int userRatings[]  = new int[20];	
	public static final double similarityScores[]  = new double[30];
	public static final double recommendations[]  = new double[20];	
	
	public static void main(String args[]) throws FileNotFoundException {
		int indexOfRecommendation = -1;
		
		readBooksIn(bookNames);
		readRatingsIn(ratings);
		getUserRatings(bookNames, userRatings);
		generateSimilarityRatings(userRatings, similarityScores, ratings);
		calculateRecommendations(ratings, similarityScores, recommendations);

		indexOfRecommendation = recommendBook(recommendations, userRatings);
		
		if(indexOfRecommendation == -1){
			System.out.println("Congratulations, you have already read all of the books in this list!");
		}else {		
			System.out.println("According to your tastes you might enjoy: " + bookNames[indexOfRecommendation]);  
		}
	}
	
	public static int recommendBook(double recommendations[], int userRatings[]) {
		/* For each book the user has not read (i.e. has a -1 rating) check the recommendations score.
		 * The higher the score the more likely the user will enjoy it, so store that rating in "recommendation"
		 * 	also store the index of that book. Continue to do this for all the books, and if the 
		 * 	score is higher than what is currently in recommendation update it, 
		 *  then return the index of the book the user is most likely to enjoy.
		 * If the user has read every book return -1
		 */
		double recommendation = 0;
		int indexOfBook = -1;
		for(int i=0; i<20; i++) {
			if (userRatings[i] == -1 && (recommendations[i]> recommendation)) {
				recommendation = recommendations[i];
				indexOfBook = i;
			}		
		}		
		return indexOfBook;
	}
	
	public static double[] calculateRecommendations(int ratings[][], double similarityScores[], double recommendations[]) {
		/*
		 * First add up all the similarity scores into a single number.
		 * Then for each book if someone has read it multiply their rating by their corresponding similarity score
		 * and add it to the total rating for that book (rXsim). After that divide this weighted average by the sum of all
		 * the weights. 
		 * The resulting number represents how likely the user is to like that book, it will be stored in the recommendations array. 
		 *  
		 */
		double rXsim = 0;
		double simPlus = 0;
		for(int k=0; k<30; k++) {
			simPlus += similarityScores[k];
		}
		for(int i=0; i < 20; i++) {
			for(int j=0; j < 30; j++) {
				if (ratings[j][i] > 0) {
					rXsim += ratings[j][i]*similarityScores[j]; 					
				}
			}
			recommendations[i] = rXsim/simPlus;
			rXsim = 0;
		}
		return recommendations;
	}
	
	public static double[] generateSimilarityRatings(int userRatings[], double similarityScores[], int ratings[][]) {
		/*
		 * This function uses cosine similarity to compute how similar an individuals tastes are to the users.
		 * For each book the user (p1) has read take square of the rating, add it to their total and take the square root of the total.
		 * Do the same for each other person.
		 * Next the function will see if both people have read the same book, if so it will calculate a similarity score by
		 * 	multiplying together the ratings they each gave to a certain book and storing it in a variable called both.
		 * To calculate the final similarity score the function uses this expression: both/(p1*p2) dividing both by the product of each users manipulated ratings.
		 * The result is a number between 0 and 1 and is stored in an array called similarityScores,
		 * 	the closer to 1 the number is the more similar that persons tastes are to the user.  
		 */
		double p1 = 0;
		double p2 = 0;
		double both = 0;
		for(int i=0; i<20; i++) {
			if(userRatings[i] > 0) {
				p1 += Math.pow(userRatings[i], 2);
			}
		}
		p1 = Math.sqrt(p1);
		for(int i=0; i<30; i++) {
			for(int j=0; j<20; j++) {
				if(ratings[i][j] > 0) {
					p2 += Math.pow(ratings[i][j], 2);
				}	
			}
			p2 = Math.sqrt(p2);
			for(int k=0; k<20; k++) {
				if ((ratings[i][k] > 0) && (userRatings[k] > 0)) {
					both += (ratings[i][k] *userRatings[k]);
				}
			}
			similarityScores[i] = both/(p1*p2);
			p2 = 0;
			both = 0;
		}
		return similarityScores;
	}
		
	public static int[] getUserRatings(String bookNames[], int userRatings[]) {
		/*
		 * This function shows the user a list of 20 books and asks for a rating.
		 * If the user has read the book they enter a a rating of 1 to 5.
		 * If the user has not read the book they enter -1.
		 * The users ratings are stored in an array called userRatings
		 */
		Scanner in = new Scanner(System.in);
		int i = 0;
		System.out.println("This program will recommend you a book you may like that you have not read. \n" 
				+ "It will compare the ratings you give to those of 30 other people.\n"
				+ "\n"
				+ "For each book shown that you have read enter a rating of 1 to 5, if you have not read the book enter a rating of -1.");
		while(i<20) {
			System.out.println("Enter a rating for: " + bookNames[i].toString());
			int userChoice = in.nextInt();
			if((0<userChoice && userChoice<6) || (userChoice == -1)) {
				userRatings[i] = userChoice;
				i++;
			}else {
				System.out.println("Enter a valid rating: 1 to 5 or -1 if you have not read the book");
			}
		}
		System.out.println("Thank you for your ratings.");
		return userRatings;
	}
	
	public static String[] readBooksIn(String bookNames[]) throws FileNotFoundException {
		/*
		 * This function reads in a text file of book names and stores them in an array called bookNames. 
		 */
		Scanner in = new Scanner(new File("C:\\eclipse workspace\\tuj66923\\src\\books.txt"));
		int i = 0;
		while (in.hasNextLine()) {
			bookNames[i] = in.nextLine();
			i++;
		}
		return bookNames;
	}
	
	public static int[][] readRatingsIn(int ratings[][]) throws FileNotFoundException {
		/*
		 * This function reads in a text file of ratings that corresponds to the list of books and stores them in a 2D array called ratings. 
		 */
		Scanner in = new Scanner(new File("C:\\eclipse workspace\\tuj66923\\src\\ratings.txt"));
		for(int i=0; i < 30; i++) {
			for(int j=0; j < 20; j++) {
				ratings[i][j] = in.nextInt();
			}
		}
		return ratings;
	}
}
