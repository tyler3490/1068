package assignment_8;
/*
 * Tyler Hyde 
 * 29 October 2019
 * Tests for the HoneyDo class
 */
public class HoneyDoListMain {
	public static void main(String args[]) {
		//make a new HoneyDo array 
		HoneyDoList honeydo = new HoneyDoList();
		
		//add 5 tasks to the array 
		for(int i = 0 ; i<5; i++) {
			honeydo.addTask(new Task("test task" + i, i, 90+i));
		}
		
		//get the number of tasks
		System.out.println(honeydo.getnumTasks());
		
		//test to string
		System.out.println(honeydo);
		
		//test shortest time (prints the INDEX of the shortest time, not the time itself)
		System.out.println(honeydo.shortestTime());
		
		//test find (again, returns the INDEX)
		System.out.println(honeydo.find("test task3"));
		
		//test total time
		System.out.println(honeydo.totalTime());
		
		//test complete task and make sure there is one less task
		honeydo.completeTask(2);
		System.out.println(honeydo.getnumTasks());

	}
}
