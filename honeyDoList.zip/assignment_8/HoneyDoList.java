package assignment_8;
/*
 * Tyler Hyde 
 * 29 October 2019
 * HoneyDo List Class 
 */
public class HoneyDoList {
	private final int INITIAL_CAPACITY = 10;
	private Task []tasks;
	private int numTasks;
	
	
/* CONSTRUCTOR */
	public HoneyDoList() {
		numTasks = 0;
		tasks = new Task[INITIAL_CAPACITY];
	}
	
/* getter for numTasks variable (for testing purposes) */
	public int getnumTasks() {
		return numTasks;
	}
	
/* toString method */
	public String toString() { 
		String a = "";
		for(int i=0; i < numTasks; i++) {
			a += tasks[i].toString() + "\n";						
		}
		return a;
	}
	
/* FIND
	 * This function returns the task the user searches for.
	 */
    public int find(String name) {
    	for(int i=0; i < numTasks; i++) {
    		if(tasks[i].getName().equalsIgnoreCase(name)) {
    			return i;
    		}
    	}
        return -1;
    }
    
/* TOTAL TIME
	 * This function returns the total amount of time to complete all tasks.
	 */
	public int totalTime() {
		int totalTime = 0;
		for(int i=0; i < numTasks; i++) {
			if(tasks[i].getEstMinsToComplete() > -1) {
				totalTime += tasks[i].getEstMinsToComplete();			
			}
		}
	    return totalTime;	
	}
	
/* SHORTEST TIME
	 * This function returns the index of the task that has the shortest completion time.
	 */
	public int shortestTime() {
		int indexOfShortestTime = -1;
		int smallest = tasks[numTasks-1].getEstMinsToComplete();
		for(int i=0; i < numTasks; i++) {
			if(tasks[i].getEstMinsToComplete() < smallest) {
				smallest = tasks[i].getEstMinsToComplete();
				indexOfShortestTime = i;		
			}	
		}
		return indexOfShortestTime;
	}

/* ADD TASK
	 * This function adds a new task at the "end" of the tasks array.
	 * If the tasks array is already full it constructs a new array of initial capacity plus
	 * the length of the original tasks array and points towards the newly constructed array.
	 * Accepts a new Task object as a parameter 
	 */
	public void addTask(Task nTask) {
		if(numTasks < tasks.length) {
			tasks[numTasks] = nTask; 
			numTasks++;
    	}else{
	    	Task newTaskArray[] = new Task[numTasks + INITIAL_CAPACITY];
	    	System.arraycopy(tasks, 0, newTaskArray, 0, tasks.length);
	        tasks = newTaskArray;
	        tasks[numTasks] = nTask; 
			numTasks++;
    	}
    }

/* COMPLETE TASK
	 * This function makes a copy of everything up to the index, puts it in tempTaskArray, 
	 * then makes a copy of everything AFTER the index (i.e. index+1) and also puts it into 
	 * a temporary task array. It then makes tasks point towards this newly constructed array that contains 
	 * one less item (the one at index). 
	 * If the index asked to be removed is greater than the number of tasks it just returns null 
	 */
	public Object completeTask(int index) {
		if(index > numTasks) {
			return null;
		}else if(numTasks < INITIAL_CAPACITY) {			
			Task tempTaskArray[] = new Task[INITIAL_CAPACITY];
			System.arraycopy(tasks, 0, tempTaskArray, 0, index);
			System.arraycopy(tasks, index+1, tempTaskArray, index, tempTaskArray.length-(index+1));
			tasks = tempTaskArray;	
			numTasks--;
		}else {
			Task tempTaskArray[] = new Task[tasks.length];
			System.arraycopy(tasks, 0, tempTaskArray, 0, index);
			System.arraycopy(tasks, index+1, tempTaskArray, index, tempTaskArray.length-(index+1));
			tasks = tempTaskArray;
			numTasks--;
		}
		return tasks;
	}
}
 

