package assignment_8;
/*
 * Tyler Hyde 
 * 29 October 2019
 * Tests for the Task class
 */
public class TaskMain {
	public static void main(String args[]) {
		//create a task 
		Task testTask = new Task("do things", 2, 120);
		
		//get the task name
		System.out.println(testTask.getName());
		
		//test the to string
		System.out.println(testTask);
		
		//print the priority, decrease it, print it again, then increase and print again
		System.out.println("Priority " + testTask.getPriority());
		testTask.decreasePriority(1);
		System.out.println("Priority " + testTask.getPriority());
		testTask.increasePriority(2);
		System.out.println("Priority " + testTask.getPriority());
		
		//get min to complete, set it, and get it again
		System.out.println("min to complete " + testTask.getEstMinsToComplete());
		testTask.setEstMinsToComplete(123);
		System.out.println("min to complete " + testTask.getEstMinsToComplete());
		
		//re name the task and print it out
		testTask.setName("new task name");
		System.out.println(testTask.getName());
		


	}

}
