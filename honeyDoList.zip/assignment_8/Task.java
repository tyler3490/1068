package assignment_8;
/*
 * Tyler Hyde 
 * 29 October 2019
 * Task Class
 * Each task has a name, priority number, and estimated min to completion
 */
public class Task {
	private String name;
	private int priority;
	private int estMinsToComplete;

//	Constructor
	public Task(String iname, int ipriority, int iestMinsToComplete) {
		name = iname;
		priority = ipriority;
		estMinsToComplete = iestMinsToComplete;
	}
	
//	Getters
	public String getName() {
		return name;
	}
	public int getPriority() {
		return priority;
	}
	public int getEstMinsToComplete() {
		return estMinsToComplete;
	}
	
//	Setters
	public void setName(String newName) {
		name = newName;
	}
	public void setEstMinsToComplete(int newEstMinsToComplete) {
		estMinsToComplete = newEstMinsToComplete;
	}

//	toString
	public String toString() {
		return("Task: " + name + ", " + "Priority: " + priority + 
				", Estimated time to complete (mins): " + estMinsToComplete);
	}

//	increase priority	
	public void increasePriority(int amount) {
		if(amount < 0) {
			; 
		}else {			
			priority += amount;
		}
	}
	
//	decrease priority
	public void decreasePriority(int amount) {
		if(amount > priority) {
			priority = 0; 
		}else {			
			priority -= amount;
		}
	}
	
}
