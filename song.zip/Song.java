package tuj66923;
/*Tyler Hyde
 * 6 September 2019
 * Assignment 2. Get You a Cat
 * 
 * This program will print a song.
 * The song is compromised of 6 verses which are in turn 
 * made up of a cap, animal noises, and a last line that 
 * is common throughout the entire song.
 */
public class Song {
//main() will call each verse.
	public static void main(String[] args) {
		verse1();
		System.out.println();
		verse2();
		System.out.println();
		verse3();
		System.out.println();
		verse4();
		System.out.println();
		verse5();
		System.out.println();
		verse6();
	}
//Each verse will call a cap, the required noises, and a last line.
	public static void verse1() {
		verse1Cap();
		lastLine();	
	}
	public static void verse2() {
		verse2Cap();
		henNoise();
		lastLine();		
	}
	public static void verse3() {
		verse3Cap();
		duckNoise();
		henNoise();
		lastLine();		
	}
	public static void verse4() {
		verse4Cap();
		gooseNoise();
		duckNoise();
		henNoise();
		lastLine();	
	}
	public static void verse5() {
		verse5Cap();
		sheepNoise();
		gooseNoise();
		duckNoise();
		henNoise();
		lastLine();	
	}
	public static void verse6() {
		verse6Cap();
		pigNoise();
		sheepNoise();
		gooseNoise();
		duckNoise();
		henNoise();
		lastLine();		
	}
//Each cap has a different animal in it. 
	public static void verse1Cap() {
		System.out.println("Bought me a cat and the cat pleased me,");
		System.out.println("I fed my cat under yonder tree.");
	}
	public static void verse2Cap() {
		System.out.println("Bought me a hen and the hen pleased me,");
		System.out.println("I fed my hen under yonder tree.");
	}	
	public static void verse3Cap() {
		System.out.println("Bought me a duck and the duck pleased me,");
		System.out.println("I fed my duck under yonder tree.");
	}	
	public static void verse4Cap() {
		System.out.println("Bought me a goose and the goose pleased me,");
		System.out.println("I fed my goose under yonder tree.");
	}	
	public static void verse5Cap() {
		System.out.println("Bought me a sheep and the sheep pleased me,");
		System.out.println("I fed my sheep under yonder tree.");
	}	
	public static void verse6Cap() {
		System.out.println("Bought me a pig and the pig pleased me,");
		System.out.println("I fed my pig under yonder tree.");
	}
//Each animal has a distinct noise.
	public static void henNoise() {
		System.out.println("Hen goes chimmy-chuck, chimmy-chuck,");		
	}
	public static void duckNoise() {
		System.out.println("Duck goes quack, quack,");		
	}
	public static void gooseNoise() {
		System.out.println("Goose goes hissy, hissy,");		
	}
	public static void sheepNoise() {
		System.out.println("Sheep goes baa, baa,");		
	}
	public static void pigNoise() {
		System.out.println("Pig goes oink, oink,");		
	}
//The last line is common throughout the song. 	
	public static void lastLine() {
		System.out.println("Cat goes fiddle-i-fee.");
	}
}