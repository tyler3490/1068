package assignment_9;
import java.util.*; 
public class Question {
	
	private static final int MIN_DIFFICULTY = 0;
	private static final int MAX_DIFFICULTY = 10;

	public int points;
	public int answerSpace; 
	public String questionText;
	public int difficulty;
	
	Random randNum = new Random();

//	constructor
	public Question(int ipoints, String iquestionText, int ianswerSpace) {
		points = ipoints;
		questionText = iquestionText;
		answerSpace = ianswerSpace;
		difficulty = randNum.nextInt(MAX_DIFFICULTY);
	}
	
//	getters
	public int getPoints() {
		return points;
	}
	
	public int getAnswerSpace() {
		return answerSpace;
	}
	
	public String getTestVersion() {
		return questionText;
	}
	public String getAnswerKeyVersion() {
		return " ";
	}
	
//	toString
	public String toString() {
		return questionText + ", worth: " + points + " points, " + "alloted answer space: " + answerSpace + ", difficulty of question: " + difficulty;  
	}
}


