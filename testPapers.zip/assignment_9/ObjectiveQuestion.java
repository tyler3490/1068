package assignment_9;
// objective question: a question with an answer
public class ObjectiveQuestion extends Question{
//	unique variable
	public String correctAnswer;

//	constructor
	public ObjectiveQuestion(int points, String questionText, int answerSpace, String correctAnswer) {
		super(points, questionText, answerSpace);
		this.correctAnswer = correctAnswer;
	}

//	getters
	public String getCorrectAnswer() {
		return correctAnswer;
	}
	
	public String getTestVersion() {
		return this.questionText;
	}

	public String getAnswerKeyVersion() {
		return this.questionText + " the answer is: " + correctAnswer;
	}
}
