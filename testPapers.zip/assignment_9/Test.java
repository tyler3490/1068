package assignment_9;

public class Test {
// counters for the total points of each question type 
	public int totalQPts= 0;
	public int totalOQPts= 0;
	public int totalFIBPts= 0;
	public int totalMCQPts= 0;


//	bank of normal questions
	Question question2 = new Question(5, "How much wood would a woodchuck chuck if a woodchuck could chuck wood?", 2);
	Question question1 = new Question(1, "Who won the Civil War?", 2);
	Question question3 = new Question(2, "Where are you?", 2);
	Question question4 = new Question(9, "Whats a computer?", 2);

//	bank of Objective Questions
	ObjectiveQuestion oq1 = new ObjectiveQuestion(5, "2 + 3 =", 2, "5");
	ObjectiveQuestion oq2 = new ObjectiveQuestion(4, "5 * 5 =", 2, "25");
	ObjectiveQuestion oq3 = new ObjectiveQuestion(2, "10 - 3 = ", 2, "7");
	ObjectiveQuestion oq4 = new ObjectiveQuestion(3, "8 / 2 =", 2, "4");
	
//	bank of fill in the blank questions
	FillInTheBlankQuestion fib1 = new FillInTheBlankQuestion(5, " is your name.", 2, "your name");
	FillInTheBlankQuestion fib2 = new FillInTheBlankQuestion(8, " was the 16th president.", 2, "Abraham Lincoln");
	FillInTheBlankQuestion fib3 = new FillInTheBlankQuestion(3, " won Super Bowl LI.", 2, "Eagles");
	FillInTheBlankQuestion fib4 = new FillInTheBlankQuestion(4, " are the best basketball team.", 2, "76ers");
	
//	bank of multiple choice questions
	public String possibleAnswers[] = {"Peter Griffin", "Scooby Doo", "Spongebob Squarepants", "Eric Cartman"};
	MultipleChoiceQuestion mcq1 = new MultipleChoiceQuestion(1, "Who lives in a pineapple under the sea?", 2, possibleAnswers[2], possibleAnswers);
	MultipleChoiceQuestion mcq2 = new MultipleChoiceQuestion(1, "Who is a dog? ", 2, possibleAnswers[1], possibleAnswers);
	MultipleChoiceQuestion mcq3 = new MultipleChoiceQuestion(10, "Who's authority must you respect?", 2, possibleAnswers[3], possibleAnswers);
	MultipleChoiceQuestion mcq4	= new MultipleChoiceQuestion(2, "Who is Stewies dad?", 2, possibleAnswers[0], possibleAnswers);

//	2d array of 4 banks of 4 different types of questions 
	public Question test[][] = {{question1, question2, question3, question4},{oq1, oq2, oq3, oq4}, {fib1, fib2, fib3, fib4}, {mcq1, mcq2, mcq3, mcq4}};

//	method to get the actual test
	public Question[][] getTest() {
		return test;
	}
	
// getters for the total points of each type of question 
	public int getTotalQPoints() {
		for(int i=0; i< test.length; i++) {
			totalQPts += test[0][i].getPoints();
		}
		return totalQPts;
	}
	public int getTotalOQPoints() {
		for(int i=0; i < test.length; i++) {
			totalOQPts += test[1][i].getPoints();
		}
		return totalOQPts;
	}
	public int getTotalFIBPoints() {
		for(int i=0; i < test.length; i++) {
			totalFIBPts += test[2][i].getPoints();
		}
		return totalFIBPts;
	}
	public int getTotalMCQPoints() {
		for(int i=0; i < test.length; i++) {
			totalMCQPts += test[3][i].getPoints();
		}
		return totalMCQPts;
	}
}







