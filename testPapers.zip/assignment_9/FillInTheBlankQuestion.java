package assignment_9;
// fill in the blank: fill in the blank with the correct answer
public class FillInTheBlankQuestion extends Question {
//	unique variable
	public String correctAnswer; 
	
//	constructor	
	public FillInTheBlankQuestion(int points, String questionText, int answerSpace, String correctAnswer) {
		super(points, questionText, answerSpace);
	this.correctAnswer = correctAnswer;
	}
	
//	getters
	public String getTestVersion() {
		return "_____________" + this.questionText;
	}
	public String getAnswerKeyVersion() {
		return ("______" + this.correctAnswer + "_______" + this.questionText);
	}
}
