package assignment_9;
// multiple choice: prints out a question with multiple choices as answers
// extends the question class 
public class MultipleChoiceQuestion extends Question{
//	unique variables
	protected String possibleAnswers[] = new String[4]; 
	public String correctAnswer; 
	
// constructor 	
	public MultipleChoiceQuestion(int points, String questionText, int answerSpace, String correctAnswer, String possibleAnswers[]) {
		super(points, questionText, answerSpace);
		this.correctAnswer = correctAnswer;
		for(int i=0; i<possibleAnswers.length; i++) {
			this.possibleAnswers[i] = possibleAnswers[i];
		}
	}
	
//	getters 
	public String getTestVersion() {
		return (this.questionText + "\n" 
				+ "1: " + possibleAnswers[0] + "\n"
				+ "2: " + possibleAnswers[1] + "\n"
				+ "3: " + possibleAnswers[2] + "\n"
				+ "4: " + possibleAnswers[3] + "\n");
	}
		
	public String getAnswerKeyVersion() {
		return (this.questionText + "\n" 
				+ "1: " + possibleAnswers[0] + "\n"
				+ "2: " + possibleAnswers[1] + "\n"
				+ "3: " + possibleAnswers[2] + "\n"
				+ "4: " + possibleAnswers[3] + "\n"
				+ "Correct Answer: " + correctAnswer + "\n");	
	}
}
