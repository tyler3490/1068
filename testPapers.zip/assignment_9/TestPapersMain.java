package assignment_9;
/*
 * Tyler Hyde 
 * 9 October 2019
 * Assignment 9: Test Papers Assignment
 */

public class TestPapersMain {
	public static void main(String args[]) {
//		create a new test object
		Test test = new Test();
		Question questions[][] = test.test;
//	print the test version 
		for(int i=0; i < questions.length; i++) {
			for(int j=0; j < questions[i].length; j++) {
				System.out.println(questions[i][j].getTestVersion());
			}
			System.out.println();
		}
		
//	print the answer key version 
		for(int i=0; i < questions.length; i++) {
			for(int j=0; j < questions[i].length; j++) {
				System.out.println(questions[i][j].getAnswerKeyVersion());
			}
			System.out.println();
		}
		
//	print the total points each type of question is worth 
		System.out.println("Total question points: " + test.getTotalQPoints());
		System.out.println("Total objective question points: " + test.getTotalOQPoints());
		System.out.println("Total fill in the blank points: " + test.getTotalFIBPoints());
		System.out.println("Total multiple choice points: " + test.getTotalMCQPoints());
		

		





	}
}