package stringPractice1068;

public class SomePracticeStringMethods {

    public static boolean isPunct(char c) {
    	if(c == '\'')
    		return true;
    	else if (c == ',')
    		return true;
    	else if (c == '.')
			return true;
    	else if (c == ';')
			return true;
    	else if (c == ':')
			return true;
    	else if (c == '!')
			return true;
    	else if (c == '?')
			return true;	 
    	return false;
    }
    
    public static int indexOfFirstPunct(String s) {
    	for(int i = 0; i < s.length(); i++) {
    		if(isPunct(s.charAt(i))) {
    			return i;
    		}
    	}
    	return -1;
    }

    public static int indexOfFirstPunct(String s, int startPosition) {
    	for(int i = startPosition; i < s.length(); i++) {
    		if(isPunct(s.charAt(i))) {
    			return i;
    		}
    	}
    	return -1;
    }

    public static int indexOfLastPunct(String s) {
    	int lastPunct = -1;
    	for(int i = 0; i < s.length(); i++) {
    		if(isPunct(s.charAt(i))) {
    			lastPunct = i;
    		}
    	}
    	if(lastPunct > -1){
    		return lastPunct;
    	}else {
    		return -1;
   		}
    }

    public static String reversed(String s) {
    	String reversedString = "";
    	for(int i = s.length()-1; i > -1; i--) {
    		reversedString += s.substring(i, i+1);	
    	}
	return reversedString;
    }

    /*
     * returns the number of times that n occurs in h. For example, if h is
     * "Mississippi" and n is "ss" the method returns 2.
     */
    public static int numOccurrences(String h, String n) {
    	int count = 0;
    	for(int i = 0; i <= h.length()-n.length(); i++) {
    		if(h.substring(i, i+n.length()).equalsIgnoreCase(n)){
    			count += 1;
    		}	
    	}
    	if(count > 0) {
    		return count;
    	}else {    		
    		return 0;
    	}
    }

    /*
     * returns true if s is the same backwards and forwards and false otherwise
     */
    public static boolean sameInReverse(String s) {
    	if(reversed(s).equalsIgnoreCase(s)) {    		
    		return true;
    	}
    	return false;
    }

    /*
     * returns a new String which is the same as s, but with all of the punctuation
     * marks removed.
     */
    public static String withoutPunct(String s) {
    	String withoutPunc = "";
    	for(int i = 0; i < s.length(); i++) {
    		if(isPunct(s.charAt(i)) == false) {
    			withoutPunc += s.substring(i, i+1);
    		}
    	}
	return withoutPunc;
    }

    /*
     * Returns a new String that looks like base appended with suffix. If base
     * already ends with suffix, it returns base.
     * 
     * For example, if base is "lightning" and suffix is "bug", returns
     * "lightningbug".
     * 
     * If base is "lightningbug" and suffix is "bug", it also returns
     * "lightningbug".
     */
    public static String appendIfMissing(String base, String suffix) {
    	if (!(base.contains(suffix))) {
    		base += suffix;
    		return base; 
    	}
	return base;
    }

    /* Returns true of s contains none of the characters
     * found in chars or false otherwise.
     * 
     * For example, if s is "
     */
    public static boolean containsNone(String s, String chars) {
    	for(int i = 0; i < s.length(); i++) {
    		if(chars.contains(s.substring(i, i+1))) {
    			return false;
    		}
    	}
    	return true;
    }
	
    public static boolean allUpperCase(String s) {
    	if((s.toUpperCase().equals(s))&&(indexOfFirstPunct(s) == -1)) {
    		return true;
    	}
	return false;
    }
	
    public static boolean allLowerCase(String s) {
    	if((s.toLowerCase().equals(s))&&(indexOfFirstPunct(s) == -1)) {
    		return true;
    	}
	return false;
    }
}
