package assignment_11;
/*
 * Tyler Hyde 
 * Big file sorter
 * 4 Dec 2019
 * 
 * */
import java.io.*;
import java.util.*;
 
public class MergeSort {
	public static void main(String args[]) throws FileNotFoundException {
		ArrayList<String> linesA = new ArrayList<String>();		
		ArrayList<String> linesB = new ArrayList<String>();
		
		int writerCount1 = 0;
		int writerCount2 = 0;
		
		readIntoSmallChunks(linesA, writerCount1, writerCount2);
		
//		merge the first batch of files
		mergeTwoChunks(linesB, 0, 0, 0, 1, 1, 0);		
		mergeTwoChunks(linesB, 0, 1, 0, 2, 2, 0);		
		mergeTwoChunks(linesB, 0, 2, 0, 3, 3, 0);		
		mergeTwoChunks(linesB, 0, 4, 0, 5, 4, 0);		
		mergeTwoChunks(linesB, 0, 6, 0, 7, 5, 0);		
		mergeTwoChunks(linesB, 0, 8, 0, 9, 6, 0);		
		mergeTwoChunks(linesB, 0, 10, 0, 1, 7, 0);		
		mergeTwoChunks(linesB, 0, 12, 0, 13, 8, 0);		
		mergeTwoChunks(linesB, 0, 14, 0, 15, 9, 0);		
		mergeTwoChunks(linesB, 0, 16, 0, 17, 10, 0);		
		mergeTwoChunks(linesB, 0, 18, 0, 19, 11, 0);

//		merge the next batch of files
		mergeTwoChunks(linesB, 1, 0, 2, 0, 1, 1);
		mergeTwoChunks(linesB, 3, 0, 4, 0, 1, 2);
		mergeTwoChunks(linesB, 5, 0, 6, 0, 1, 3);
		mergeTwoChunks(linesB, 7, 0, 8, 0, 1, 4);
		mergeTwoChunks(linesB, 9, 0, 10, 0, 1, 5);
		
//		merge the next batch of files including the leftover from the previous batch
		mergeTwoChunks(linesB, 1, 1, 1, 2, 2, 1);
		mergeTwoChunks(linesB, 1, 3, 1, 4, 2, 2);
		mergeTwoChunks(linesB, 11, 0, 1, 5, 2, 3);
		
//		merge the final batch of files including the leftover from the previous batch 		
		mergeTwoChunks(linesB, 2, 1, 2, 2, 19, 19);		
		mergeTwoChunks(linesB, 19, 19, 2, 3, 20, 20);
	}
		
	
	public static void mergeTwoChunks(ArrayList<String> linesB, int writerCount1, int writerCount2, int writerCount3, int writerCount4, int writerCount5, int writerCount6) throws FileNotFoundException {
//		make 2 temp arrays (left and right)
		ArrayList<String> L = new ArrayList<String>();	
		ArrayList<String> R = new ArrayList<String>();	
		
		Scanner in1 = new Scanner(new File("C:\\Users/Tyler/Desktop/mergeSortFiles/temp_" + writerCount1 + "_" + writerCount2 + ".txt"));
		Scanner in2 = new Scanner(new File("C:\\Users/Tyler/Desktop/mergeSortFiles/temp_" + writerCount3 + "_" + writerCount4 + ".txt"));
		
//		put all the lines from each small file into either the L or R array 
		while(in1.hasNext()) {
			String s = in1.nextLine();				
			if(s.equals("")) { 
				;
			}else {
				L.add(s);
			}
		}
		while(in2.hasNext()) {
			String t = in2.nextLine();				
			if(t.equals("")) {
				;
			}else {
				R.add(t);
			}
		}				
 		
//		then merge the two
		while(L.size() > 0 || R.size() > 0 ) {
//			eventually the L or R array will be empty, in that case add the remainder of them to the end of linesB, they will be sorted in subsequent mergers
			if(L.size() == 0 || R.size() == 0 ) {
				linesB.addAll(L);
				linesB.addAll(R);
				break;
			}
//			if the thing on the left is "smaller" than the thing on the right it comes first so add it to linesB and remove it from the L array
			if(L.get(0).compareTo(R.get(0)) < 0 ){
				linesB.add(L.get(0));
				L.remove(0);
//			if theyre equal then add them both to linesB and remove them from their respective array
			}else if(L.get(0).compareTo(R.get(0)) == 0 ) {
				linesB.add(L.get(0));				
				linesB.add(R.get(0));
				L.remove(0);
				R.remove(0);
			}
//			else the thing on the right is "smaller", thus comes first so add it to linesB and remove it from the R array
			else {
				linesB.add(R.get(0));
				R.remove(0);
			}
 		}
//		finally clear the L, R, and linesB array so they can receive the next batch of small files
		fileWriter(linesB, writerCount5, writerCount6);
		linesB.clear();
		L.clear();
		R.clear();
	}		
				
				


	public static void readIntoSmallChunks(ArrayList<String> linesA, int writerCount1, int writerCount2) throws FileNotFoundException {
//laptop location		
//		Scanner in = new Scanner(new File("C:\\eclipse workspace/tuj66923/src/Aesop_Shakespeare_Shelley_Twain.txt"));
//desktop location
		Scanner in = new Scanner(new File("C:\\Users/Tyler/Desktop/Aesop_Shakespeare_Shelley_Twain.txt"));
		
		int i = 0;
//		read in stuff unitl you reach the number of lines you want
		while(in.hasNextLine()) {
			String s = in.nextLine().strip().trim();
//			skip blank lines
			if(s.equals("")) {
				;
//			if the line isnt blank add it to linesA
			}else {	
				linesA.add(s);
				i++;
//				once you get the size of the chunk you want then jump in here and sort the file and call the writer
				if(i == 134974/20) {
					Collections.sort(linesA);
					fileWriter(linesA, writerCount1, writerCount2);
//				reset i, and linesA so it can hold the next group of lines  
					i = 0;
					linesA.clear();
					writerCount2++;
					
				}
			}
//			then jump out and keep reading until you hit another chunk of lines 
		}		
	}

	public static void fileWriter(ArrayList<String> linesA, int writerCount1, int writerCount2) throws FileNotFoundException{ 
//		write the lines in linesA to a file
		PrintStream out = new PrintStream(new File("C:\\Users/Tyler/Desktop/mergeSortFiles/temp_" + writerCount1 + "_" + writerCount2 + ".txt"));
		int i=0;
		while(i<linesA.size()) {
			out.println(linesA.get(i));
			i++;
		}
	}
}

	
	
	
	
	
	
