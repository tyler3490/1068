package tuj66923;
/*Tyler Hyde
 * 29 August 2019
 * Assignment 1. Greetings
 * 
 * This program will print a greeting to Professor Fiore.
 */
public class Greeting {
	public static void main(String[] args) {
		
		System.out.println("Good morning, Professor Fiore.");
	
	}
}
