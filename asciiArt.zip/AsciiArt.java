package tuj66923;
/*Tyler Hyde
 * 18 September 2019
 * Assignment 3. Draw a pretty picture
 * 
 * This program will print a grid of cells with a cap on each end.
 * The static variable SIZE controls the ratio of columns to rows,
 * there will be SIZE*4 rows and SIZE/2 columns for any integer >= 2
 */
public class AsciiArt {
	// The variable SIZE works for any integer >= 2
	static final int SIZE = 4;

	public static void main(String args[]) {
		grid();
	}
	public static void grid() {
	// The nested loop below prints out a "cap" SIZE*2 characters in length for each column
		for(int i = 0; i < (SIZE/2); i++) {
			System.out.print(" ");
			for(int j = 0; j < (SIZE*2); j++) {
				System.out.print("=");
			}
		}
		System.out.print(" ");
		System.out.println();
		
	// This loop controls the number of rows in the main figure (SIZE*4) 
		for(int i=0; i < SIZE*4; i++) {
			
			// This loop controls the number of columns in the main figure (SIZE/2 rounded down)
			for(int j=0; j < SIZE/2; j++) {
				System.out.print("|");	
				
				// This loop prints out each of the columns contents (SIZE*2 characters per column)			
				for(int k=0; k < SIZE*2; k++) {
					System.out.print("-");
				}
			}
			System.out.println("|");
		}

		// This nested loop prints a "bottom" SIZE*2 characters in length for each column
		for(int i = 0; i < (SIZE/2); i++) {
			System.out.print(" ");
			for(int j = 0; j < (SIZE*2); j++) {
				System.out.print("=");
			}
		}
		System.out.print(" ");
	}
}
