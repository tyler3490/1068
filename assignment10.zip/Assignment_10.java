package tuj66923;

/*
 * Tyler Hyde 
 * 18 October 2019
 * This program will play hang man with the user but unlike a normal game it will cheat.
 * First the program will generate a random number and create an arraylist of the words that are that length, it will then begin the game.
 * If the user enters a word then the program will discard that word from the arraylist if it finds it. 
 * If the user enters a letter the program will just discard all the words in the arraylist that contain that letter.
 * The program will continue this way until one of two things happens:
 * 	1. there is only one word left in the arraylist.
 * 	2. if the program tried to remove the words with the chosen letter from the arraylist it would result in an empty array.
 * In both cases it will choose one of the words left (or the last word in case 1) and set it as the word that will win the game if the user guesses it. 
 * It will then continue in a normal manner until the user either wins or runs out of guesses.
 * If the user runs out of guesses and still hasnt won the computer will choose a word at random from the remaining words in the array and tell the user that 
 * 	was the word all along.
 */

import java.io.*;
import java.util.*;

public class Assignment_10 {
	public static final int RAND_MIN = 2;
	public static final int RAND_MAX = 14;
	public static void main(String args[]) throws FileNotFoundException {
		ArrayList<String> collection = new ArrayList<String>();		
		generateCollection(collection);
		initializeList(collection);
		Scanner in = new Scanner(System.in);
		int numGuesses = 10;
		String wordToGuess = "";
		String lettersUsed = "";
		
		System.out.println("You are going to play a game of hangman with the computer, you have " + numGuesses + " guesses. You may enter a word or a letter, make an entry:");
		String userChoice = in.next().toLowerCase().strip();
		
		while(numGuesses > 1) /*they have guesses left*/ {
			if(userChoice.length() > 1) /*if there is more than 1 letter than the user guessed a word*/ {
				if(collection.contains(userChoice) && collection.size() > 1) /*check if the word is in the array, if so remove it*/ {
					String c = userChoice;
					collection.removeIf((n)->(n.contains(c)));
					numGuesses--;
				}else if(collection.size() == 1) /*if it was the last word assign it as the word the user is trying to guess*/{
					wordToGuess = collection.get(0);
					numGuesses--;
				}else /*decrement if none of the conditions are met*/{
					numGuesses--;				
				}
			}else /*user guessed a letter*/ {
				lettersUsed += userChoice; /*add it to list to show the user what theyve used already*/
				if(collection.size() >= 1) /*if there is something in the collection*/ {
					String c = userChoice;
					if(allWordsContain(collection, userChoice))/*check all the words, if they all have the same letter you chose, pick one and make it the word to guess*/ {
						Random rand = new Random();
						wordToGuess = collection.get(rand.nextInt(collection.size()));
						numGuesses--;
					}else /*remove the word if it would not result in an empty array*/{
						collection.removeIf((n)->(n.contains(c)));
						numGuesses--;						
					}	
				}else /*decrement if none of the conditions are met*/{
					numGuesses--;				
				}
			}
			if(userChoice.equals(wordToGuess)) /*word to guess will only be set if there is one word in the array or taking words with common letters out will result in an empty array*/{
				System.out.println("CORRECT, YOU WIN!!!");
				return;
			}else /*grab another letter/word from the user*/{				
				System.out.println("Enter another word or letter, you have " + numGuesses + " guesses left. Letters you have guessed already: " + lettersUsed);
				userChoice = in.next().toLowerCase().strip();
			}
		}			
		if(userChoice.equals(wordToGuess) || (collection.size() == 1 && collection.contains(userChoice))) /*check their final guess to see if it matches, will either match the wordToGuess or it will be the only thing left*/{
			System.out.println("CORRECT, YOU WIN!!!");
				return;
		}else /*if not then they lost, pick a word at random from 0 to the length of the array (could be 0 i.e. 1 item in the array) and tell them that was the word*/{				
			Random rand = new Random();
			System.out.println("You have run out of guesses, the correct word was: " + collection.get(rand.nextInt(collection.size())));
		}
	}

//	function to check if all the words in the array contain a common letter
	public static boolean allWordsContain(ArrayList<String> collection, String userChoice) {
		int count = 0;
		for(int i=0; i<collection.size(); i++) {
			if(collection.get(i).contains(userChoice)) {
				count++;
			}
		}
		if(count == collection.size()) {
			return true;
		}
		return false;
	}

//	chooses a random length and keeps only the words of that length 
	public static void initializeList(ArrayList<String> collection) {
		Random rand = new Random();
		int randLength = RAND_MIN + rand.nextInt(RAND_MAX - RAND_MIN+1);
		collection.removeIf((n) -> (n.length() != randLength));
	}

//  reads in all the words from the text file and creates the arraylist 	
	public static ArrayList<String> generateCollection(ArrayList<String> collection) throws FileNotFoundException {
		Scanner in = new Scanner(new File("C:\\eclipse workspace/tuj66923/src/tuj66923/word_list.txt"));
		while(in.hasNext()) {
			String c = in.next();
			collection.add(c);
		}
		return collection;
	}
}
		
	








